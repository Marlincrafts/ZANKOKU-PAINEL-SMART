# ZANKOKU PAINEL — Smart Overlay

Projeto Android Kotlin + WebView. A interface HTML original foi preservada.

## Recursos incluídos
- Sobreposição Android com botão flutuante arrastável.
- Painel WebView sobre outros aplicativos, com minimizar e encerrar.
- Menu nativo **ZANKOKU SMART SYSTEM** (engrenagem) com opções ativar/desativar:
  - Adaptação automática do tamanho do painel à tela detectada.
  - Verificação de compatibilidade (exibe fabricante, modelo, Android/API e resolução).
  - Sugestões inteligentes offline (regras locais; não é um modelo de IA remoto).
  - Botão flutuante.
- Preferências persistidas localmente.

## Permissões e limites
O Android exige que o usuário conceda manualmente “Sobrepor a outros apps”. O serviço de primeiro plano mantém a sobreposição enquanto o sistema permitir. Fabricantes podem impor restrições de bateria/execução em segundo plano.

O painel não altera o Free Fire, não injeta código, não lê memória do jogo e não automatiza a mira. As sensibilidades são referências para aplicação manual. A detecção automática melhora a compatibilidade da interface, mas não garante funcionamento em todo aparelho/ROM.

## Compilação
Abra a pasta no Android Studio com Android SDK instalado e compile o módulo `app`. Este pacote é código-fonte; não é um APK compilado nem foi testado em aparelho físico.

## Gerar APK automaticamente pelo GitHub
1. Envie o conteúdo desta pasta para um repositório GitHub.
2. Abra a aba **Actions** e execute **Build ZANKOKU APK** (ou faça push na branch `main`).
3. Quando terminar, abra a execução e baixe o artefato `ZANKOKU-PAINEL-debug-apk`.
4. Dentro do ZIP do artefato estará `app-debug.apk`, que pode ser transferido ao Samsung Galaxy A04 para teste.

O APK gerado pelo fluxo é de depuração e ainda deve ser instalado e testado no aparelho. O fluxo automatiza a compilação; não substitui o teste físico.
