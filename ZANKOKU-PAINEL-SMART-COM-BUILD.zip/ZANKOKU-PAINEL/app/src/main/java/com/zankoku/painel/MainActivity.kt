package com.zankoku.painel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 8, 18)
        window.navigationBarColor = android.graphics.Color.rgb(16, 8, 18)
        if (Settings.canDrawOverlays(this)) {
            startOverlay()
            Toast.makeText(this, "ZANKOKU: botão flutuante ativado", Toast.LENGTH_LONG).show()
            finish()
        } else {
            Toast.makeText(this, "Autorize 'Sobrepor a outros apps' para ativar o painel.", Toast.LENGTH_LONG).show()
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), REQUEST_OVERLAY)
        }
    }

    @Deprecated("Android overlay permission result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startOverlay()
                Toast.makeText(this, "Painel pronto! Toque na caveira para abrir.", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this, "Permissão não concedida.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun startOverlay() {
        val intent = Intent(this, OverlayService::class.java).apply { action = "com.zankoku.painel.ENABLE_OVERLAY" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    companion object { private const val REQUEST_OVERLAY = 4102 }
}
