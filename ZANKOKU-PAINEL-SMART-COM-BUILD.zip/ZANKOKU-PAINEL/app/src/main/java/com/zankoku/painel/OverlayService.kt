package com.zankoku.painel

import android.app.Service
import android.app.Notification
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var expanded = false

    override fun onCreate() {
        super.onCreate()
        startAsForegroundService()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if(getSharedPreferences("zankoku_smart",Context.MODE_PRIVATE).getBoolean("floating_enabled",true)) showBubble()
    }

    private fun startAsForegroundService() {
        val channelId = "zankoku_overlay"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "ZANKOKU Painel flutuante", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ZANKOKU PAINEL ativo")
                .setContentText("Toque no botão flutuante para abrir o painel.")
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ZANKOKU PAINEL ativo")
                .setContentText("Toque no botão flutuante para abrir o painel.")
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7401, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7401, notification)
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "com.zankoku.painel.ENABLE_OVERLAY") {
            getSharedPreferences("zankoku_smart",Context.MODE_PRIVATE).edit().putBoolean("floating_enabled",true).apply()
            showBubble()
        }
        return START_STICKY
    }
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke) }

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "☠"; textSize = 27f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = shape(Color.rgb(232, 48, 157), 50, Color.rgb(255, 145, 216)); elevation = dp(8).toFloat()
            contentDescription = "Abrir ZANKOKU PAINEL"
        }
        val lp = WindowManager.LayoutParams(dp(58), dp(58), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(180) }
        var rawX = 0f; var rawY = 0f; var baseX = 0; var baseY = 0; var dragged = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { rawX=e.rawX; rawY=e.rawY; baseX=lp.x; baseY=lp.y; dragged=false; true }
                MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-rawX).toInt(); val dy=(e.rawY-rawY).toInt(); if(abs(dx)>dp(5)||abs(dy)>dp(5)) dragged=true; lp.x=(baseX+dx).coerceAtLeast(0); lp.y=(baseY+dy).coerceAtLeast(0); try { wm.updateViewLayout(view,lp) } catch (_:Exception) {}; true }
                MotionEvent.ACTION_UP -> { if(!dragged) expandPanel(); true }
                else -> true
            }
        }
        try { wm.addView(view, lp); bubble=view } catch (_:Exception) { Toast.makeText(this,"Confira a permissão de sobreposição.",Toast.LENGTH_LONG).show(); stopSelf() }
    }

    private fun expandPanel() {
        if (expanded) return
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=shape(Color.rgb(16,8,18),22,Color.rgb(255,79,184)); clipToOutline=true }
        val bar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(14),dp(8),dp(8),dp(8)); setBackgroundColor(Color.rgb(39,18,39)) }
        val title = TextView(this).apply { text="☠  ZANKOKU PAINEL"; textSize=14f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD }
        bar.addView(title,LinearLayout.LayoutParams(0,dp(40),1f))
        bar.addView(button("⚙"){showSmartSettings()},LinearLayout.LayoutParams(dp(42),dp(40)))
        bar.addView(button("—"){collapsePanel()},LinearLayout.LayoutParams(dp(42),dp(40)))
        bar.addView(button("×"){stopSelf()},LinearLayout.LayoutParams(dp(42),dp(40)))
        val web=WebView(this).apply { settings.javaScriptEnabled=true; settings.domStorageEnabled=true; webViewClient=WebViewClient(); webChromeClient=WebChromeClient(); setBackgroundColor(Color.rgb(16,8,18)); loadUrl("file:///android_asset/index.html") }
        root.addView(bar,LinearLayout.LayoutParams(-1,dp(56))); root.addView(web,LinearLayout.LayoutParams(-1,0,1f))
        val m=resources.displayMetrics
        val prefs=getSharedPreferences("zankoku_smart",Context.MODE_PRIVATE)
        val adaptive=prefs.getBoolean("adaptive_layout",true)
        val widthRatio=if(adaptive) .94f else .92f
        val heightRatio=if(adaptive) .84f else .82f
        val panelWidth=(m.widthPixels*widthRatio).toInt().coerceAtMost(dp(560))
        val panelHeight=(m.heightPixels*heightRatio).toInt().coerceAtMost((m.heightPixels*.90f).toInt())
        val lp=WindowManager.LayoutParams(panelWidth,panelHeight,type(),WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.CENTER }
        try { bubble?.let{wm.removeView(it)}; bubble=null; wm.addView(root,lp); panel=root; expanded=true } catch (_:Exception) { showBubble(); Toast.makeText(this,"Não foi possível abrir o painel.",Toast.LENGTH_SHORT).show() }
    }

    private fun showSmartSettings() {
        val prefs=getSharedPreferences("zankoku_smart",Context.MODE_PRIVATE)
        val keys=arrayOf("adaptive_layout","compatibility_check","smart_tips","floating_enabled")
        val labels=arrayOf(
            "Adaptação automática da tela",
            "Verificação de compatibilidade",
            "Sugestões inteligentes offline",
            "Botão flutuante ativo"
        )
        val checked=BooleanArray(keys.size){i->prefs.getBoolean(keys[i],true)}
        val info="Aparelho: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nTela: ${resources.displayMetrics.widthPixels} × ${resources.displayMetrics.heightPixels} px\n\nAs sugestões são locais e baseadas nas características do aparelho; não exigem conta nem enviam dados."
        val dialog=AlertDialog.Builder(this)
            .setTitle("ZANKOKU SMART SYSTEM")
            .setMessage(info)
            .setMultiChoiceItems(labels,checked){_,which,isChecked->
                prefs.edit().putBoolean(keys[which],isChecked).apply()
                when(keys[which]) {
                    "adaptive_layout" -> Toast.makeText(this,if(isChecked) "Adaptação automática ativada. Reabra o painel para aplicar." else "Adaptação automática desativada.",Toast.LENGTH_SHORT).show()
                    "compatibility_check" -> Toast.makeText(this,if(isChecked) "Verificação de compatibilidade ativada." else "Verificação de compatibilidade desativada.",Toast.LENGTH_SHORT).show()
                    "smart_tips" -> Toast.makeText(this,if(isChecked) "Sugestões inteligentes offline ativadas." else "Sugestões inteligentes offline desativadas.",Toast.LENGTH_SHORT).show()
                    "floating_enabled" -> if(!isChecked) {
                        try { bubble?.let { wm.removeView(it) } } catch (_:Exception) {}
                        bubble=null
                        if(expanded) { try { panel?.let { wm.removeView(it) } } catch (_:Exception) {}; panel=null; expanded=false }
                        Toast.makeText(this,"Botão flutuante desativado. Abra o ZANKOKU novamente para reativar.",Toast.LENGTH_LONG).show()
                    } else { showBubble(); Toast.makeText(this,"Botão flutuante ativado.",Toast.LENGTH_SHORT).show() }
                }
            }
            .setPositiveButton("Fechar",null)
            .create()
        dialog.window?.setType(type())
        dialog.show()
        dialog.window?.setType(type())
    }

    private fun button(label:String, action:()->Unit)=TextView(this).apply { text=label; textSize=20f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=shape(Color.rgb(76,29,65),12,Color.rgb(132,51,105)); setOnClickListener{action()} }
    private fun collapsePanel() { if(!expanded)return; try{panel?.let{wm.removeView(it)}}catch(_:Exception){}; panel=null; expanded=false; if(getSharedPreferences("zankoku_smart",Context.MODE_PRIVATE).getBoolean("floating_enabled",true)) showBubble() }
    override fun onDestroy(){try{panel?.let{wm.removeView(it)}}catch(_:Exception){};try{bubble?.let{wm.removeView(it)}}catch(_:Exception){};panel=null;bubble=null;super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
